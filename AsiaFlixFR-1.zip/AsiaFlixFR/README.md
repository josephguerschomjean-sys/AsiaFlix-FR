# AsiaFlix FR — prototype Android

Application Android native en Kotlin + Jetpack Compose.

## Fonctionnalités incluses
- Catalogue de démonstration de films asiatiques
- Recherche par titre, pays ou genre
- Filtres : action, romance, arts martiaux, dramas coréens, films chinois/japonais, horreur
- Fiche détaillée par film
- Bouton « Trouver où regarder » qui ouvre une recherche JustWatch France
- Interface sombre adaptée au streaming

## Ouvrir le projet
1. Décompressez `AsiaFlixFR.zip`.
2. Ouvrez le dossier `AsiaFlixFR` dans Android Studio.
3. Laissez Gradle synchroniser les dépendances.
4. Lancez l'application sur un émulateur ou un téléphone Android.

## Important
Ceci est un prototype fonctionnel d'interface, pas encore une plateforme hébergeant des vidéos.
Les titres sont des exemples de catalogue et leur disponibilité gratuite ou en version française n'est pas garantie. Le bouton renvoie vers une recherche JustWatch ; vérifiez la disponibilité dans votre pays, les options gratuites et la piste audio française.
Pour publier une version complète, il faudra enrichir le catalogue avec une source de métadonnées autorisée, vérifier les territoires et droits de diffusion, puis intégrer uniquement des lecteurs ou liens fournis par les ayants droit. Aucun film n'est hébergé par cette application.
