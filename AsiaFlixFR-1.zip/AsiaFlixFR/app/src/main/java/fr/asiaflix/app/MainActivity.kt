package fr.asiaflix.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.net.URLEncoder

private val Ink = Color(0xFF0B0B10)
private val Panel = Color(0xFF191923)
private val Red = Color(0xFFFF4358)
private val Muted = Color(0xFFB9B9C7)

data class Film(
    val title: String,
    val country: String,
    val year: String,
    val genres: List<String>,
    val synopsis: String,
    val vfConfirmed: Boolean = false
)

private val categories = listOf("Tout", "Action", "Romance", "Arts martiaux", "Drames coréens", "Films chinois", "Films japonais", "Horreur")

private val films = listOf(
    Film("Train to Busan", "Corée du Sud", "2016", listOf("Action", "Horreur", "Drames coréens"), "Un père et sa fille tentent de survivre à une épidémie dans un train. Vérifie la disponibilité du doublage français sur la plateforme."),
    Film("The Wandering Earth", "Chine", "2019", listOf("Action", "Films chinois"), "Une équipe tente de sauver la Terre alors que le Soleil menace de la détruire. Vérifie la piste audio française."),
    Film("Ip Man", "Hong Kong", "2008", listOf("Action", "Arts martiaux", "Films chinois"), "Un maître de Wing Chun défend sa communauté pendant une période troublée."),
    Film("Your Name", "Japon", "2016", listOf("Romance", "Films japonais"), "Deux adolescents découvrent qu'ils échangent mystérieusement leurs corps."),
    Film("The Call", "Corée du Sud", "2020", listOf("Horreur", "Drames coréens"), "Deux femmes reliées par un téléphone ancien modifient le cours des événements."),
    Film("Our Times", "Taïwan", "2015", listOf("Romance"), "Une romance adolescente entre souvenirs, amitié et premiers amours."),
    Film("Rurouni Kenshin", "Japon", "2012", listOf("Action", "Arts martiaux", "Films japonais"), "Un ancien assassin tente de protéger les autres sans reprendre son ancienne vie."),
    Film("The Sadness", "Taïwan", "2021", listOf("Horreur", "Action"), "Un couple lutte pour survivre lors d'une épidémie violente. Film réservé à un public averti.")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AsiaFlixApp { film -> openLegalSearch(film.title) } }
    }

    private fun openLegalSearch(title: String) {
        val query = URLEncoder.encode(title, "UTF-8")
        val url = "https://www.justwatch.com/fr/recherche?q=$query"
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AsiaFlixApp(onWatch: (Film) -> Unit) {
    var query by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Tout") }
    var selectedFilm by remember { mutableStateOf<Film?>(null) }

    val filtered = films.filter { film ->
        val matchesText = (film.title + " " + film.country + " " + film.genres.joinToString(" "))
            .contains(query, ignoreCase = true)
        val matchesCategory = selectedCategory == "Tout" || selectedCategory in film.genres
        matchesText && matchesCategory
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Red, background = Ink, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Ink) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(bottom = 28.dp)
            ) {
                item {
                    Column(
                        Modifier.fillMaxWidth()
                            .background(Brush.verticalGradient(listOf(Color(0xFF34131D), Ink)))
                            .padding(start = 20.dp, end = 20.dp, top = 26.dp, bottom = 20.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("ASIA", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black)
                            Text("FLIX", color = Red, fontSize = 27.sp, fontWeight = FontWeight.Black)
                            Spacer(Modifier.weight(1f))
                            Surface(color = Red.copy(alpha = .16f), shape = RoundedCornerShape(50)) {
                                Text("VF • GRATUIT", color = Red, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(Modifier.height(20.dp))
                        Text("Le cinéma asiatique,", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("en français. 🇰🇷 🇨🇳 🇯🇵", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Red)
                        Spacer(Modifier.height(8.dp))
                        Text("Explore les films et trouve où les regarder légalement.", color = Muted, fontSize = 14.sp)
                        Spacer(Modifier.height(18.dp))
                        Row(
                            Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(horizontal = 14.dp, vertical = 13.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Search, contentDescription = "Rechercher", tint = Muted)
                            Spacer(Modifier.width(10.dp))
                            Box(Modifier.weight(1f)) {
                                if (query.isEmpty()) Text("Titre, pays, genre…", color = Muted)
                                BasicTextField(value = query, onValueChange = { query = it }, singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp), modifier = Modifier.fillMaxWidth())
                            }
                        }
                    }
                }
                item {
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        categories.forEach { category ->
                            FilterChip(
                                selected = selectedCategory == category,
                                onClick = { selectedCategory = category },
                                label = { Text(category) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Red,
                                    selectedLabelColor = Color.White,
                                    containerColor = Panel,
                                    labelColor = Muted
                                )
                            )
                        }
                    }
                }
                item {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (query.isBlank() && selectedCategory == "Tout") "À découvrir" else "Résultats", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(8.dp))
                        Text("${filtered.size} films", color = Muted, fontSize = 12.sp)
                    }
                }
                if (filtered.isEmpty()) {
                    item { Text("Aucun film trouvé. Essaie un autre titre ou filtre.", color = Muted, modifier = Modifier.padding(20.dp)) }
                }
                items(filtered) { film ->
                    FilmRow(film = film, onClick = { selectedFilm = film })
                }
                item {
                    Column(Modifier.padding(horizontal = 20.dp, vertical = 18.dp)) {
                        Divider(color = Color(0xFF33333E))
                        Spacer(Modifier.height(12.dp))
                        Text("À savoir", color = Red, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(5.dp))
                        Text("Le catalogue est une démo. Les droits, la disponibilité gratuite et la VF varient selon le pays et la plateforme. Vérifie la langue audio avant de lancer un film.", color = Muted, fontSize = 12.sp, lineHeight = 17.sp)
                    }
                }
            }
        }
    }

    selectedFilm?.let { film ->
        AlertDialog(
            onDismissRequest = { selectedFilm = null },
            containerColor = Panel,
            title = { Text(film.title, color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${film.country} • ${film.year}", color = Red, fontWeight = FontWeight.SemiBold)
                    Text(film.genres.joinToString("  •  "), color = Muted, fontSize = 12.sp)
                    Text(film.synopsis, color = Color.White)
                    Text("La VF n'est pas garantie : vérifie la fiche du diffuseur.", color = Muted, fontSize = 12.sp)
                }
            },
            confirmButton = {
                Button(onClick = { onWatch(film); selectedFilm = null }, colors = ButtonDefaults.buttonColors(containerColor = Red)) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("Trouver où regarder")
                }
            },
            dismissButton = { TextButton(onClick = { selectedFilm = null }) { Text("Fermer", color = Muted) } }
        )
    }
}

@Composable
fun FilmRow(film: Film, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
            .background(Panel, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(width = 78.dp, height = 100.dp)
                .background(Brush.linearGradient(listOf(Color(0xFF6B1D31), Color(0xFF242434))), RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(film.title.split(" ").take(2).joinToString("\n"), color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, lineHeight = 17.sp)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(film.title, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${film.country} • ${film.year}", color = Muted, fontSize = 12.sp)
            Text(film.genres.take(3).joinToString(" · "), color = Color(0xFFFF9AA6), fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text("Voir les options légales  →", color = Red, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}
